<?php 
    session_start();
    if(isset($_SESSION['email'])){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donation Certificate</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="../includes/jquery_latest.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        #certificate {
            margin-top: 5%;
            padding: 5%;
            text-align: center;
            border: 10px solid red;
            border-radius: 20px;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: red;
            font-size: 48px;
        }
        p, strong {
            font-size: 20px;
        }
        .logo {
            width: 100px;
            height: auto;
            margin-bottom: 20px;
        }
        .signature {
            margin-top: 50px;
            text-align: left;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 m-auto" id="certificate">
                <img src="../images/Logo.jpg" alt="Logo" class="logo">
                <h1>Certificate of Appreciation</h1>
                <p>This certificate is proudly presented to:</p>
                <strong><?php echo $_SESSION['name']; ?></strong>
                <p>for their selfless act of donating blood and saving lives.</p>
                <hr>
                <p>Organized by: <strong>YAH Youth Organization</strong></p>
                <p class="signature">Date: __________________</p>
                <p class="signature">Chairman: __________________</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php
}
else{
    header('Location:login.php');
}
?>
