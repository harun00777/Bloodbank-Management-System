<?php 
session_start();
if(isset($_SESSION['email'])) {
?>
<html>
    <head>
        <style>
            .donate-form {
                box-shadow: 3px 3px 3px gray;
                border-left: 1px solid gray;
                border-top: 1px solid gray;
                border-radius: 7px;
                padding: 7px;
            }
        </style>
    </head>
<body>
    <div class="row" style="margin-top: 4%;">
        <div class="col-md-3 m-auto donate-form">
            <center><h4>Blood Donation Form</h4></center><br>
            <form action="" method="post">
                <div class="form-group">
                    <label for="bgroup">Blood Group:</label>
                    <select name="bgroup" class="form-control" required>
                        <option value="">-Select-</option>
                        <option value="A">A</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B">B</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                    </select>
                </div><br>
                <div class="form-group">
                    <label for="units">No of Units:</label>
                    <input type="text" class="form-control" name="units" placeholder="No of units (in ml)" required pattern="\d+" title="Please enter a valid number">
                </div><br>
                <div class="form-group">
                    <label for="lst_date">Last Donation Date:</label>
                    <input type="date" name="lst_date" class="form-control" required><br>
                </div>
                <div class="form-group">
                    <label for="crt_date">Current Date:</label>
                    <input type="date" name="crt_date" class="form-control" required><br>
                </div>
                <div class="form-group">
                    <label for="disease">Disease (if any)</label>
                    <textarea name="disease" cols="45" rows="3" class="form-control" placeholder="Mention disease if any (Optional)"></textarea>
                </div><br>
                <input type="submit" class="btn btn-danger" name="donate_submit" value="Submit">
            </form>
        </div>
        <div class="col-md-6 m-auto">
            <img src="../images/image2.jpg" class="img-fluid" style="border-radius:3%;">
        </div>
    </div>
<br>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $previousDate = DateTime::createFromFormat('Y-m-d', $_POST["lst_date"]);
    $currentDate = DateTime::createFromFormat('Y-m-d', $_POST["crt_date"]);

    // Check if date creation was successful
    if (!$previousDate || !$currentDate) {
        echo "<center><h4 style='color:red;'>Invalid date format. Please check and try again.</h4></center>";
    } else {
        // Ensure lst_date is not later than crt_date
        if ($previousDate > $currentDate) {
            echo "<center><h4 style='color:red;'>Last donation date cannot be later than the current date. Please check and try again.</h4></center>";
        } else {
            $difference = $currentDate->diff($previousDate);
            if ($difference->y == 0 && $difference->m < 3) {
                echo "<center><h4 style='color:red;'>Cannot donate blood! Last donation was less than 3 months ago.</h4></center>";
            } else {
                echo "<center><h4 style='color:green;'>You are eligible to donate blood!</h4></center>";
            }
        }
    }
}
} else {
    header('Location: login.php');
    exit();
}
?>
</body>
</html>
