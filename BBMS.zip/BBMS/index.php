<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Management</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- External CSS -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-danger">
        <a class="navbar-brand" href="index.php">Blood Bank Management System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="admin/login.php">Admin</a></li>
                <li class="nav-item"><a class="nav-link" href="donor/login.php">Donor</a></li>
                <li class="nav-item"><a class="nav-link" href="patient/login.php">Patient</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-md-8">
                <h4>What is Blood Bank Management System?</h4>
                <p>
                    A Blood Bank Management System (BBMS) is a digital platform designed to streamline the operations of blood banks by managing donor registration, blood collection, testing, storage, and distribution. In Bangladesh, where the demand for blood often exceeds supply, a BBMS plays a crucial role in saving lives by ensuring the efficient management of blood resources. It provides real-time updates on blood availability, facilitates communication between donors, hospitals, and recipients, and ensures transparency by maintaining detailed records of all transactions. Additionally, it supports underserved areas and reduces costs through automation.
                </p>
                <button class="btn btn-danger">Read more...</button>
            </div>
            <div class="col-md-4 text-center">
                <img class="img-fluid" src="../BBMS/images/image1.jpg" alt="Blood Bank System">
            </div>
        </div>
    </div>

    <!-- Importance Section -->
    <div class="container my-5">
        <h4>Importance of a Blood Bank Management System in Bangladesh</h4>
        <ul>
            <li><strong>Streamlined Blood Donor Management:</strong> Maintains a reliable donor database for emergencies.</li>
            <li><strong>Real-Time Blood Availability Updates:</strong> Reduces delays in finding blood for critical needs.</li>
            <li><strong>Enhanced Transparency:</strong> Documents all processes to ensure accountability.</li>
            <li><strong>Support for Emergencies:</strong> Facilitates quick access to blood during disasters.</li>
            <li><strong>Data-Driven Decision Making:</strong> Provides insights for planning campaigns and managing resources.</li>
            <li><strong>Accessibility for Rural Areas:</strong> Extends services to underserved regions.</li>
        </ul>
    </div>

    <!-- Centers Section -->
    <div class="container my-5">
        <h4>Our Centers</h4>
        <div class="row">
            <div class="col-md-3">
                <div class="card p-3">
                    <h5>Dhaka</h5>
                    <p>Reliable blood bank services in the capital city.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <h5>Chittagong</h5>
                    <p>Supporting blood needs in the port city.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <h5>Khulna</h5>
                    <p>Efficient and timely blood delivery services.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <h5>Rajshahi</h5>
                    <p>Providing life-saving resources in northern Bangladesh.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-danger text-center text-white py-3">
        &copy; 2024 Made by Harun
    </footer>

    <!-- Bootstrap JS -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
